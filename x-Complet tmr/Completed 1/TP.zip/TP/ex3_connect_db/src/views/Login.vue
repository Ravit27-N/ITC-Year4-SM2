<template>
<div>
    <form class="container_login">
        <div class="mb-3">
          <span class="title">Username</span>
          <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="username" v-model="username">
         
        </div>
        <div class="mb-3">
          <span class="title">Password</span>
          <input type="password" class="form-control" id="exampleInputPassword1" placeholder="password" v-model="password">
        </div>
      
        <button @click="loginClick" type="submit" class="btn btn-primary">Log in</button>
    </form>
</div>
</template>


<script>
import axios from "axios";

export default {
  data(){
    return{
      username:"",
      password:""
    }
  },
  methods:{
    loginClick(){
        axios.post(`http://localhost:3001/api/login?username=${this.username}&password=${this.password}`)
        .then(response => (
          this.info = response
        ))
        .then(()=>{
          if(this.info){
            if(this.info.data.login=='true'){
              location.href = '/home';
            }else{
              alert("Username and password doesnot exit");
            }
          }
        })
    },
    
  }
}
</script>

<style scoped>
  .container_login{
    justify-content: center;
    margin: auto;
    width: 40vw;
    border: solid 2px black;
    padding: 20px;
  }
  .title{
    float: left;
    font-size: 1.2em;
    font-weight: bold;
  }
</style>