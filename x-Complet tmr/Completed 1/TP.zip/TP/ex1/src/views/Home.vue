<template>
<div>
  <div class="card">
      <div class="card-header">
        Home
      </div>
      <div class="card-body">
        <h5 class="card-title">Welcome to Homepage</h5>
        <a href="/" class="btn btn-danger">Log Out</a>
      </div>
   </div> 
</div>
</template>


<script>
export default {
  
}
</script>

<style scoped>

</style>