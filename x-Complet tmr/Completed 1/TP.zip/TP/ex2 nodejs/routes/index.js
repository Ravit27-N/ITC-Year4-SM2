const router = require("express").Router();

const { json } = require("body-parser");
const {readUser,writeUSer} = require("../db/db");


router.get('/',(req,res)=>{
   const user = readUser();
   res.status(200).json({message:'success',user:user});
});
router.post('/login', async (req,res)=>{
 
  const {username,password} = req.query;
  const users = readUser();
  var login_st = 0;

  for(var i in users){
    if(users[i].username == username){
      if(users[i].password == password){
        login_st=1;
        res.json({"login":"true"});
      }
    }
  }

  if(login_st==0){
    res.json({"login":"false"});
  }
 
});
router.post('/register',async (req,res)=>{
  
  

});


module.exports = router;
