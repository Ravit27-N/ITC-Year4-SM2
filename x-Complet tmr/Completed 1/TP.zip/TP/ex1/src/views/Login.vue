<template>
<div>
    <form class="container_login">
        <div class="mb-3">
          <span class="title">Email</span>
          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="email@gmail.com">
         
        </div>
        <div class="mb-3">
          <span class="title">Password</span>
          <input type="password" class="form-control" id="exampleInputPassword1" placeholder="password">
        </div>
      
        <button type="submit" class="btn btn-primary">Log in</button>
    </form>
</div>
</template>


<script>
export default {
  
}
</script>

<style scoped>
  .container_login{
    justify-content: center;
    margin: auto;
    width: 40vw;
    border: solid 2px black;
    padding: 20px;
  }
  .title{
    float: left;
    font-size: 1.2em;
    font-weight: bold;
  }
</style>